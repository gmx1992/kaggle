### Titanic_survival  泰坦尼克生存预测



Jupyter notebook to play with Titanic dataset and Machine Learning